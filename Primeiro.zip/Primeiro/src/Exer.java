import java.util.Scanner;
public class Exer {
	public static void main (String[] args) {
		Scanner numero1 = new Scanner(System.in);
		System.out.print("Digite o numero 1: ");
		int num1 = numero1.nextInt();
		
		Scanner numero2 = new Scanner(System.in);
		System.out.print("Digite o numero 2: ");
		int num2 = numero2.nextInt();
		
		Scanner numero3 = new Scanner(System.in);
		System.out.print("Digite o numero 3: ");
		int num3 = numero3.nextInt();
		
		int soma,sub;
		float resto;
		soma = num1+num2+num3;
		sub = num1-num2-num3;
		resto = (num1*num2)%num3;
		System.out.print("A soma dos 3 numeros �: "+soma);
		System.out.print("\nA subtra��o dos 3 numeros �: "+sub);
		System.out.print("\nO resto da divis�o dos produtos dos dois primeiros pelo terceiro �: "+resto);
	}
}
