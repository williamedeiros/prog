
public class exemplo {
	public static void main (String[] args) {
		int num1,num2,num3,soma,subtracao,resto;
		num1 = 2;
		num2 = 3;
		num3 = 5;
		soma = num1+num2+num3;
		subtracao = num1-num2-num3;
		resto = (num1*num2)%num3;
		System.out.print("A soma dos 3 numeros �: "+soma);
		System.out.print("\nA subtra��o dos 3 numeros �: "+subtracao);
		System.out.print("\nO resto da divis�o dos produtos dos dois primeiros pelo terceiro �: "+resto);
	}
}
